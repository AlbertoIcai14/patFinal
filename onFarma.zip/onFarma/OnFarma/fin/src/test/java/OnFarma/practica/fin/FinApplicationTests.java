package OnFarma.practica.fin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FinApplicationTests {

	@Test
	void contextLoads() {
	}

}
