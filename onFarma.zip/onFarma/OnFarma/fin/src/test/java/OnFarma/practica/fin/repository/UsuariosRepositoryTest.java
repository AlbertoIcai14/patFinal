package OnFarma.practica.fin.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.transaction.annotation.Transactional;

import OnFarma.practica.fin.model.Usuarios;

import static org.assertj.core.api.BDDAssertions.then;


@SpringBootTest
public class UsuariosRepositoryTest {
	
	@Autowired
	private UsuariosRepository usuariosRepository;
	
	@Test
	@Sql(scripts="/sql-data.sql")
	@Transactional
	public void given_repository_when_find_by_correo_and_clave_then_Ok() {
		//Given
		
		//When
		Usuarios usuarios = usuariosRepository.findByCorreoAndClave("a@a.com", "sql14");
		
		//Then
		then(usuarios).isEqualTo(1);
	}

}
