package OnFarma.practica.fin.controller;

import java.util.Set;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static OnFarma.practica.fin.Utils.asJsonString;
import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.when;
import static org.springframework.http.MediaType.APPLICATION_JSON_VALUE;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import OnFarma.practica.fin.model.Carrito;
import OnFarma.practica.fin.service.CarritoService;

@SpringBootTest
@AutoConfigureMockMvc
public class CarritoControllerTest {
	
	 @Autowired
	 private MockMvc mockMvc;
	 
	 @MockBean
	 private CarritoService service;
	 
	 @Test
	 public void given_controller_when_getComprado_then_Ok() throws Exception {
		 
		 //Given
		 Carrito carrito = getCarrito();
		 Set<Carrito> expectedList = Set.of(carrito);
		 
		 //When
		 when(service.buscarPorComprado("", "")).thenReturn(expectedList);
		 
		 //Then
		 this.mockMvc.perform(get("/api/carrito/comprado").contentType(APPLICATION_JSON_VALUE))
					 .andDo(print())
			         .andExpect(status().isOk())
			         .andExpect(content().string(containsString(asJsonString(expectedList))));
	 }
	 
	 private Carrito getCarrito() {
		 return Carrito.builder()
				 .idcompra(null)
				 .medicamento("paracetamol")
				 .codigoproducto("55435")
				 .cantidad(2)
				 .correo("a@a.com")
				 .control(1)
				 .build();
	 }

}
