package OnFarma.practica.fin.service;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.transaction.annotation.Transactional;
//import javax.validation.constraints.Size;

import OnFarma.practica.fin.model.Usuarios;

@SpringBootTest
public class UsuariosServiceTest {
	
	@Autowired
	private UsuariosService usuariosService;
	
	@Test
	@Sql(scripts="/sql-data.sql")
	@Transactional
	public void given_repository_when_delete_ususarios_then_Ok() {
		Usuarios u = getUsuarios();
		
		usuariosService.borrarUsuarios(u);
		
		//assertTrue(usuariosService.obtenerIdusuario("l@l.es").size==0);
		
	}
	
	 private Usuarios getUsuarios() {
		 return Usuarios.builder()
				 .idusuario(null)
				 .correo("l@l.es")
				 .nombre("Lawrence")
				 .clave("sql17")
				 .dni("65483302M")
				 .build();
	 }
	

}
