package OnFarma.practica.fin.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import OnFarma.practica.fin.model.Carrito;
import OnFarma.practica.fin.service.CarritoService;

@RestController
@RequestMapping("/api/carrito")
public class CarritoController {
	
	@Autowired
	private CarritoService carritoService;
	
	@GetMapping("/correo")
	public ResponseEntity<Set<Carrito>> findByEmail(@RequestParam("busqueda")String busqueda){
		final Set<Carrito> compra = carritoService.buscarPorCorreo(busqueda);
		return new ResponseEntity<>(compra,HttpStatus.OK);
	}
	
	@GetMapping("/comprado")
	public ResponseEntity<Set<Carrito>> findByComprado(@RequestParam("busqueda")String busqueda){
		final Set<Carrito> comprado = carritoService.buscarPorComprado(busqueda,"1");
		return new ResponseEntity<>(comprado,HttpStatus.OK);
	}
	
	@GetMapping("/noComprado")
	public ResponseEntity<Set<Carrito>> findByNoComprado(@RequestParam("busqueda")String busqueda){
		final Set<Carrito> comprado = carritoService.buscarPorComprado(busqueda,"0");
		return new ResponseEntity<>(comprado,HttpStatus.OK);
	}
	
	@PostMapping("/add")
	public ResponseEntity<Carrito> addItem(@RequestBody Carrito carrito){
		Carrito c = carritoService.crearItem(carrito);
		return new ResponseEntity<>(c,HttpStatus.CREATED);
	}
	
	@PutMapping("/actualizar/{idcompra}")
	public ResponseEntity<Carrito> actualizarCarrito(@RequestBody Carrito carrito, @PathVariable("idcompra") String idcompra){
		Carrito c = carritoService.actualizarCarrito(carrito);
		return new ResponseEntity<>(c,HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/borrar/{idcompra}")
	public ResponseEntity<Carrito> borrarCarrito(@RequestBody Carrito carrito, @PathVariable("idcompra") String idcompra){
		carritoService.borrarCarrito(carrito);
		return new ResponseEntity<>(HttpStatus.OK);
	}
}
