package OnFarma.practica.fin.model;

import java.util.HashMap;
import java.util.Map;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
"OBJECTID",
"CODCNH",
"NOMBRE",
"DIRECCION",
"TELEFONO",
"TELEFONO2",
"TELEFAX",
"CODMU",
"MUNICIPIOS",
"CODPROV",
"PROVINCIAS",
"CODAUTO",
"COMUNIDADES",
"CODPOSTAL",
"NCAMAS",
"CODFI",
"FINALIDAD_ASISITENCIAL",
"CODPAT",
"DEPENDENCIA_PATRIMONIAL",
"CODFU",
"DEPENDENCIA_FUNCIONAL",
"ACREDOCENT",
"ESCOMPLE",
"FORCOMPLE",
"CODIDCOM",
"ALTA",
"CERRADO",
"CAPITAL",
"CIERREFECH",
"CONCIERTO",
"EMAIL",
"TAC",
"RM",
"GAM",
"HEM",
"ASD",
"LIT",
"BCO",
"ALI",
"SPECT",
"PET",
"MAMOS",
"DO",
"DIAL",
"X",
"Y",
"CalidadGeocodificacion"
})
@Generated("jsonschema2pojo")
public class Attributes {

@JsonProperty("OBJECTID")
private Integer objectid;
@JsonProperty("CODCNH")
private String codcnh;
@JsonProperty("NOMBRE")
private String nombre;
@JsonProperty("DIRECCION")
private String direccion;
@JsonProperty("TELEFONO")
private String telefono;
@JsonProperty("TELEFONO2")
private String telefono2;
@JsonProperty("TELEFAX")
private String telefax;
@JsonProperty("CODMU")
private String codmu;
@JsonProperty("MUNICIPIOS")
private String municipios;
@JsonProperty("CODPROV")
private String codprov;
@JsonProperty("PROVINCIAS")
private String provincias;
@JsonProperty("CODAUTO")
private String codauto;
@JsonProperty("COMUNIDADES")
private String comunidades;
@JsonProperty("CODPOSTAL")
private String codpostal;
@JsonProperty("NCAMAS")
private String ncamas;
@JsonProperty("CODFI")
private String codfi;
@JsonProperty("FINALIDAD_ASISITENCIAL")
private String finalidadAsisitencial;
@JsonProperty("CODPAT")
private String codpat;
@JsonProperty("DEPENDENCIA_PATRIMONIAL")
private String dependenciaPatrimonial;
@JsonProperty("CODFU")
private String codfu;
@JsonProperty("DEPENDENCIA_FUNCIONAL")
private String dependenciaFuncional;
@JsonProperty("ACREDOCENT")
private String acredocent;
@JsonProperty("ESCOMPLE")
private String escomple;
@JsonProperty("FORCOMPLE")
private String forcomple;
@JsonProperty("CODIDCOM")
private String codidcom;
@JsonProperty("ALTA")
private String alta;
@JsonProperty("CERRADO")
private String cerrado;
@JsonProperty("CAPITAL")
private String capital;
@JsonProperty("CIERREFECH")
private String cierrefech;
@JsonProperty("CONCIERTO")
private String concierto;
@JsonProperty("EMAIL")
private String email;
@JsonProperty("TAC")
private String tac;
@JsonProperty("RM")
private String rm;
@JsonProperty("GAM")
private String gam;
@JsonProperty("HEM")
private String hem;
@JsonProperty("ASD")
private String asd;
@JsonProperty("LIT")
private String lit;
@JsonProperty("BCO")
private String bco;
@JsonProperty("ALI")
private String ali;
@JsonProperty("SPECT")
private String spect;
@JsonProperty("PET")
private String pet;
@JsonProperty("MAMOS")
private String mamos;
@JsonProperty("DO")
private String _do;
@JsonProperty("DIAL")
private String dial;
@JsonProperty("X")
private Double x;
@JsonProperty("Y")
private Double y;
@JsonProperty("CalidadGeocodificacion")
private String calidadGeocodificacion;
@JsonIgnore
private Map<String, Object> additionalProperties = new HashMap<String, Object>();

@JsonProperty("OBJECTID")
public Integer getObjectid() {
return objectid;
}

@JsonProperty("OBJECTID")
public void setObjectid(Integer objectid) {
this.objectid = objectid;
}

@JsonProperty("CODCNH")
public String getCodcnh() {
return codcnh;
}

@JsonProperty("CODCNH")
public void setCodcnh(String codcnh) {
this.codcnh = codcnh;
}

@JsonProperty("NOMBRE")
public String getNombre() {
return nombre;
}

@JsonProperty("NOMBRE")
public void setNombre(String nombre) {
this.nombre = nombre;
}

@JsonProperty("DIRECCION")
public String getDireccion() {
return direccion;
}

@JsonProperty("DIRECCION")
public void setDireccion(String direccion) {
this.direccion = direccion;
}

@JsonProperty("TELEFONO")
public String getTelefono() {
return telefono;
}

@JsonProperty("TELEFONO")
public void setTelefono(String telefono) {
this.telefono = telefono;
}

@JsonProperty("TELEFONO2")
public String getTelefono2() {
return telefono2;
}

@JsonProperty("TELEFONO2")
public void setTelefono2(String telefono2) {
this.telefono2 = telefono2;
}

@JsonProperty("TELEFAX")
public String getTelefax() {
return telefax;
}

@JsonProperty("TELEFAX")
public void setTelefax(String telefax) {
this.telefax = telefax;
}

@JsonProperty("CODMU")
public String getCodmu() {
return codmu;
}

@JsonProperty("CODMU")
public void setCodmu(String codmu) {
this.codmu = codmu;
}

@JsonProperty("MUNICIPIOS")
public String getMunicipios() {
return municipios;
}

@JsonProperty("MUNICIPIOS")
public void setMunicipios(String municipios) {
this.municipios = municipios;
}

@JsonProperty("CODPROV")
public String getCodprov() {
return codprov;
}

@JsonProperty("CODPROV")
public void setCodprov(String codprov) {
this.codprov = codprov;
}

@JsonProperty("PROVINCIAS")
public String getProvincias() {
return provincias;
}

@JsonProperty("PROVINCIAS")
public void setProvincias(String provincias) {
this.provincias = provincias;
}

@JsonProperty("CODAUTO")
public String getCodauto() {
return codauto;
}

@JsonProperty("CODAUTO")
public void setCodauto(String codauto) {
this.codauto = codauto;
}

@JsonProperty("COMUNIDADES")
public String getComunidades() {
return comunidades;
}

@JsonProperty("COMUNIDADES")
public void setComunidades(String comunidades) {
this.comunidades = comunidades;
}

@JsonProperty("CODPOSTAL")
public String getCodpostal() {
return codpostal;
}

@JsonProperty("CODPOSTAL")
public void setCodpostal(String codpostal) {
this.codpostal = codpostal;
}

@JsonProperty("NCAMAS")
public String getNcamas() {
return ncamas;
}

@JsonProperty("NCAMAS")
public void setNcamas(String ncamas) {
this.ncamas = ncamas;
}

@JsonProperty("CODFI")
public String getCodfi() {
return codfi;
}

@JsonProperty("CODFI")
public void setCodfi(String codfi) {
this.codfi = codfi;
}

@JsonProperty("FINALIDAD_ASISITENCIAL")
public String getFinalidadAsisitencial() {
return finalidadAsisitencial;
}

@JsonProperty("FINALIDAD_ASISITENCIAL")
public void setFinalidadAsisitencial(String finalidadAsisitencial) {
this.finalidadAsisitencial = finalidadAsisitencial;
}

@JsonProperty("CODPAT")
public String getCodpat() {
return codpat;
}

@JsonProperty("CODPAT")
public void setCodpat(String codpat) {
this.codpat = codpat;
}

@JsonProperty("DEPENDENCIA_PATRIMONIAL")
public String getDependenciaPatrimonial() {
return dependenciaPatrimonial;
}

@JsonProperty("DEPENDENCIA_PATRIMONIAL")
public void setDependenciaPatrimonial(String dependenciaPatrimonial) {
this.dependenciaPatrimonial = dependenciaPatrimonial;
}

@JsonProperty("CODFU")
public String getCodfu() {
return codfu;
}

@JsonProperty("CODFU")
public void setCodfu(String codfu) {
this.codfu = codfu;
}

@JsonProperty("DEPENDENCIA_FUNCIONAL")
public String getDependenciaFuncional() {
return dependenciaFuncional;
}

@JsonProperty("DEPENDENCIA_FUNCIONAL")
public void setDependenciaFuncional(String dependenciaFuncional) {
this.dependenciaFuncional = dependenciaFuncional;
}

@JsonProperty("ACREDOCENT")
public String getAcredocent() {
return acredocent;
}

@JsonProperty("ACREDOCENT")
public void setAcredocent(String acredocent) {
this.acredocent = acredocent;
}

@JsonProperty("ESCOMPLE")
public String getEscomple() {
return escomple;
}

@JsonProperty("ESCOMPLE")
public void setEscomple(String escomple) {
this.escomple = escomple;
}

@JsonProperty("FORCOMPLE")
public String getForcomple() {
return forcomple;
}

@JsonProperty("FORCOMPLE")
public void setForcomple(String forcomple) {
this.forcomple = forcomple;
}

@JsonProperty("CODIDCOM")
public String getCodidcom() {
return codidcom;
}

@JsonProperty("CODIDCOM")
public void setCodidcom(String codidcom) {
this.codidcom = codidcom;
}

@JsonProperty("ALTA")
public String getAlta() {
return alta;
}

@JsonProperty("ALTA")
public void setAlta(String alta) {
this.alta = alta;
}

@JsonProperty("CERRADO")
public String getCerrado() {
return cerrado;
}

@JsonProperty("CERRADO")
public void setCerrado(String cerrado) {
this.cerrado = cerrado;
}

@JsonProperty("CAPITAL")
public String getCapital() {
return capital;
}

@JsonProperty("CAPITAL")
public void setCapital(String capital) {
this.capital = capital;
}

@JsonProperty("CIERREFECH")
public String getCierrefech() {
return cierrefech;
}

@JsonProperty("CIERREFECH")
public void setCierrefech(String cierrefech) {
this.cierrefech = cierrefech;
}

@JsonProperty("CONCIERTO")
public String getConcierto() {
return concierto;
}

@JsonProperty("CONCIERTO")
public void setConcierto(String concierto) {
this.concierto = concierto;
}

@JsonProperty("EMAIL")
public String getEmail() {
return email;
}

@JsonProperty("EMAIL")
public void setEmail(String email) {
this.email = email;
}

@JsonProperty("TAC")
public String getTac() {
return tac;
}

@JsonProperty("TAC")
public void setTac(String tac) {
this.tac = tac;
}

@JsonProperty("RM")
public String getRm() {
return rm;
}

@JsonProperty("RM")
public void setRm(String rm) {
this.rm = rm;
}

@JsonProperty("GAM")
public String getGam() {
return gam;
}

@JsonProperty("GAM")
public void setGam(String gam) {
this.gam = gam;
}

@JsonProperty("HEM")
public String getHem() {
return hem;
}

@JsonProperty("HEM")
public void setHem(String hem) {
this.hem = hem;
}

@JsonProperty("ASD")
public String getAsd() {
return asd;
}

@JsonProperty("ASD")
public void setAsd(String asd) {
this.asd = asd;
}

@JsonProperty("LIT")
public String getLit() {
return lit;
}

@JsonProperty("LIT")
public void setLit(String lit) {
this.lit = lit;
}

@JsonProperty("BCO")
public String getBco() {
return bco;
}

@JsonProperty("BCO")
public void setBco(String bco) {
this.bco = bco;
}

@JsonProperty("ALI")
public String getAli() {
return ali;
}

@JsonProperty("ALI")
public void setAli(String ali) {
this.ali = ali;
}

@JsonProperty("SPECT")
public String getSpect() {
return spect;
}

@JsonProperty("SPECT")
public void setSpect(String spect) {
this.spect = spect;
}

@JsonProperty("PET")
public String getPet() {
return pet;
}

@JsonProperty("PET")
public void setPet(String pet) {
this.pet = pet;
}

@JsonProperty("MAMOS")
public String getMamos() {
return mamos;
}

@JsonProperty("MAMOS")
public void setMamos(String mamos) {
this.mamos = mamos;
}

@JsonProperty("DO")
public String getDo() {
return _do;
}

@JsonProperty("DO")
public void setDo(String _do) {
this._do = _do;
}

@JsonProperty("DIAL")
public String getDial() {
return dial;
}

@JsonProperty("DIAL")
public void setDial(String dial) {
this.dial = dial;
}

@JsonProperty("X")
public Double getX() {
return x;
}

@JsonProperty("X")
public void setX(Double x) {
this.x = x;
}

@JsonProperty("Y")
public Double getY() {
return y;
}

@JsonProperty("Y")
public void setY(Double y) {
this.y = y;
}

@JsonProperty("CalidadGeocodificacion")
public String getCalidadGeocodificacion() {
return calidadGeocodificacion;
}

@JsonProperty("CalidadGeocodificacion")
public void setCalidadGeocodificacion(String calidadGeocodificacion) {
this.calidadGeocodificacion = calidadGeocodificacion;
}

@JsonAnyGetter
public Map<String, Object> getAdditionalProperties() {
return this.additionalProperties;
}

@JsonAnySetter
public void setAdditionalProperty(String name, Object value) {
this.additionalProperties.put(name, value);
}

}