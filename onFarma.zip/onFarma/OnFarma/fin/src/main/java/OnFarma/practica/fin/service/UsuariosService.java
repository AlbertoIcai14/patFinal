package OnFarma.practica.fin.service;

import OnFarma.practica.fin.model.Usuarios;

public interface UsuariosService {
	
	public Usuarios login(String correo, String clave);
	
	Usuarios crearUsuarios(Usuarios usuario);
	
	Usuarios actualizarUsuarios(Usuarios usuario);
	
	void borrarUsuarios(Usuarios usuario);
	
	Usuarios obtenerIdusuario(String direccionCorreo);

}
