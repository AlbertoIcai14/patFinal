package OnFarma.practica.fin.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Table("carrito")
public class Carrito {
	
	@Id
	private Long idcompra;
	private String medicamento;
	private String codigoproducto;
	private Integer cantidad;
	private String correo;
	private Integer control;

}
