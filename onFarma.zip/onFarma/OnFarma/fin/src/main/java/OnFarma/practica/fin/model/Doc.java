package OnFarma.practica.fin.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "tipo",
    "url",
    "secc",
    "fecha"
})
public class Doc {

    @JsonProperty("tipo")
    private Integer tipo;
    @JsonProperty("url")
    private String url;
    @JsonProperty("secc")
    private Boolean secc;
    @JsonProperty("fecha")
    private Integer fecha;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("tipo")
    public Integer getTipo() {
        return tipo;
    }

    @JsonProperty("tipo")
    public void setTipo(Integer tipo) {
        this.tipo = tipo;
    }

    @JsonProperty("url")
    public String getUrl() {
        return url;
    }

    @JsonProperty("url")
    public void setUrl(String url) {
        this.url = url;
    }

    @JsonProperty("secc")
    public Boolean getSecc() {
        return secc;
    }

    @JsonProperty("secc")
    public void setSecc(Boolean secc) {
        this.secc = secc;
    }

    @JsonProperty("fecha")
    public Integer getFecha() {
        return fecha;
    }

    @JsonProperty("fecha")
    public void setFecha(Integer fecha) {
        this.fecha = fecha;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
