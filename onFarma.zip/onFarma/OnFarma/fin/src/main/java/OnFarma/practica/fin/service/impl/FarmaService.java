package OnFarma.practica.fin.service.impl;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import OnFarma.practica.fin.model.FarmaSearchModel;


@Service
public class FarmaService {
	//url tiene el valor de la url de bandera.url que se define en application.properties
	@Value("${farma_nombre_medicamentos.url}")
	private String url;
	@Value("${farma_nombre_registros.url}")
	private String url2;

	public FarmaSearchModel getMedicamentos(String busqueda) {
		final RestTemplate template = new RestTemplate();
		final String urlFinal = url + busqueda;
		System.out.println(urlFinal);
		final HttpMethod method = HttpMethod.GET;
		//ResponseEntity<List<FarmaSearchModel>> response = template.exchange(urlFinal, method, null, new ParameterizedTypeReference<List<FarmaSearchModel>>(){});
		ResponseEntity<FarmaSearchModel> response = template.exchange(urlFinal, method, null, new ParameterizedTypeReference<FarmaSearchModel>(){});
		return  response.getBody();
	}
	public FarmaSearchModel getRegistros(String busqueda) {
		final RestTemplate template = new RestTemplate();
		final String urlFinal = url2 + busqueda;
		System.out.println(urlFinal);
		final HttpMethod method = HttpMethod.GET;
		//ResponseEntity<List<FarmaSearchModel>> response = template.exchange(urlFinal, method, null, new ParameterizedTypeReference<List<FarmaSearchModel>>(){});
		ResponseEntity<FarmaSearchModel> response = template.exchange(urlFinal, method, null, new ParameterizedTypeReference<FarmaSearchModel>(){});
		return  response.getBody();
	}
}