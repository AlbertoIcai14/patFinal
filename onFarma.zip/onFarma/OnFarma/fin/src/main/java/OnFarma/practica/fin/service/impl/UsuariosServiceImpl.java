package OnFarma.practica.fin.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import OnFarma.practica.fin.model.Usuarios;
import OnFarma.practica.fin.repository.UsuariosRepository;
import OnFarma.practica.fin.service.UsuariosService;

@Service
public class UsuariosServiceImpl implements UsuariosService {
	
	@Autowired
	UsuariosRepository usuariosRepository;
	
	@Override
	public Usuarios login(String correo, String clave) {
		return usuariosRepository.findByCorreoAndClave(correo, clave);
	}

	@Override
	public Usuarios crearUsuarios(Usuarios usuario) {
		return usuariosRepository.save(usuario);
	}
	
	@Override
	public Usuarios actualizarUsuarios(Usuarios usuario) {
		return usuariosRepository.save(usuario);
	}
	
	@Override
	public void borrarUsuarios(Usuarios usuario) {
		usuariosRepository.delete(usuario);
	}

	@Override
	public Usuarios obtenerIdusuario(String direccionCorreo) {
		return usuariosRepository.obtenerId(direccionCorreo);
	}
	

}
