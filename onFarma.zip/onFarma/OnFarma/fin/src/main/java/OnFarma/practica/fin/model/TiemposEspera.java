package OnFarma.practica.fin.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "especie",
    "tejido",
    "cantidad",
    "unidadTiempo",
    "observaciones"
})
public class TiemposEspera {

    @JsonProperty("especie")
    private Especie_ especie;
    @JsonProperty("tejido")
    private Tejido tejido;
    @JsonProperty("cantidad")
    private Object cantidad;
    @JsonProperty("unidadTiempo")
    private UnidadTiempo unidadTiempo;
    @JsonProperty("observaciones")
    private String observaciones;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("especie")
    public Especie_ getEspecie() {
        return especie;
    }

    @JsonProperty("especie")
    public void setEspecie(Especie_ especie) {
        this.especie = especie;
    }

    @JsonProperty("tejido")
    public Tejido getTejido() {
        return tejido;
    }

    @JsonProperty("tejido")
    public void setTejido(Tejido tejido) {
        this.tejido = tejido;
    }

    @JsonProperty("cantidad")
    public Object getCantidad() {
        return cantidad;
    }

    @JsonProperty("cantidad")
    public void setCantidad(Object cantidad) {
        this.cantidad = cantidad;
    }

    @JsonProperty("unidadTiempo")
    public UnidadTiempo getUnidadTiempo() {
        return unidadTiempo;
    }

    @JsonProperty("unidadTiempo")
    public void setUnidadTiempo(UnidadTiempo unidadTiempo) {
        this.unidadTiempo = unidadTiempo;
    }

    @JsonProperty("observaciones")
    public String getObservaciones() {
        return observaciones;
    }

    @JsonProperty("observaciones")
    public void setObservaciones(String observaciones) {
        this.observaciones = observaciones;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
