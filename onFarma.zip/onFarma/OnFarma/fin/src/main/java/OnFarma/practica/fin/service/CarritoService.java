package OnFarma.practica.fin.service;

import java.util.Set;

import OnFarma.practica.fin.model.Carrito;

public interface CarritoService {

	Set<Carrito> buscarPorCorreo(String direccionCorreo);
	
	Set<Carrito> buscarPorComprado(String direccionCorreo, String control);
	
	Set<Carrito> buscarPorNoComprado(String direccionCorreo, String control);
	
	Carrito crearItem(Carrito carrito);
	
	Carrito actualizarCarrito(Carrito carrito);
	
	void borrarCarrito(Carrito carrito);
	
}
