package OnFarma.practica.fin.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import OnFarma.practica.fin.model.CentrosSaludSearchModel;


@Service
public class CentrosSaludService {
	
	@Value("${centrosDeSalud.url}")
	private String url;
	
	public CentrosSaludSearchModel getCentrosSalud(String atributo, String busqueda) {
		final RestTemplate template = new RestTemplate();
		final String urlFinal = url+atributo+"%20%3D%20%27"+busqueda+"%27&outFields=*&outSR=4326&f=json";
		final HttpMethod method = HttpMethod.GET;
		
		System.out.println(urlFinal);
		
		final ResponseEntity<CentrosSaludSearchModel> response = template.exchange(urlFinal, method, null, CentrosSaludSearchModel.class);

		return response.getBody();
	}
}
