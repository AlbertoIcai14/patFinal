package OnFarma.practica.fin.model;



import com.sun.istack.NotNull;

import lombok.Data;

@Data
public class User {

	@NotNull
	//@Size(min = 5, max = 12)
	private String nombre;
	private String apellidos;
	private int edad;
	//@NotBlank
	//@Size(min = 5, max = 12)
	private String correo;
	private String clave;
}
