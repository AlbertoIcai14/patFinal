package OnFarma.practica.fin.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import OnFarma.practica.fin.model.Usuarios;
import OnFarma.practica.fin.service.UsuariosService;

@RestController
@RequestMapping("api/usuarios")
public class UsuariosController {
	
	@Autowired
	private UsuariosService usuariosService;
	
	@PostMapping("/login")
	public ResponseEntity<String> login(@RequestParam("correo") String correo, @RequestParam("clave") String clave){
		if(usuariosService.login(correo,clave)!=null){
			return new ResponseEntity<>("1",HttpStatus.OK);
		}else {
			return new ResponseEntity<>("0",HttpStatus.UNAUTHORIZED);
		}
	}
	
	@PostMapping("/registrarse")
	public ResponseEntity<Usuarios> crearUsuarios(@RequestBody Usuarios usuario){
		Usuarios u = usuariosService.crearUsuarios(usuario);
		return new ResponseEntity<>(u,HttpStatus.CREATED);
	}
	
	@PutMapping("/actualizar/{idusuario}")
	public ResponseEntity<Usuarios> actualizarUsuarios(@RequestBody Usuarios usuario, @PathVariable("idusuario") String idusuario){
		Usuarios u = usuariosService.actualizarUsuarios(usuario);
		return new ResponseEntity<>(u,HttpStatus.NO_CONTENT);
	}
	
	@DeleteMapping("/borrar/{idusuario}")
	public ResponseEntity<Usuarios> borrarUsuarios(@RequestBody Usuarios usuario, @PathVariable("idusuario") String idusuario){
		usuariosService.borrarUsuarios(usuario);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@GetMapping("/correo")
	public ResponseEntity<Usuarios> buscarPorCorreo(@RequestParam("busqueda")String busqueda){
		Usuarios u = usuariosService.obtenerIdusuario(busqueda);
		return new ResponseEntity<>(u,HttpStatus.OK);
	}

}
