package OnFarma.practica.fin.repository;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import OnFarma.practica.fin.model.Usuarios;

public interface UsuariosRepository extends CrudRepository<Usuarios,String> {
	
	
	@Query("SELECT * FROM usuarios WHERE correo =:correo AND clave =:clave")
	Usuarios findByCorreoAndClave(@Param("correo") String correo, @Param("clave") String clave);
	
	@Query("SELECT * FROM usuarios WHERE correo =:direccionCorreo")
	Usuarios obtenerId(@Param("direccionCorreo") String direccionCorreo);
	
}

