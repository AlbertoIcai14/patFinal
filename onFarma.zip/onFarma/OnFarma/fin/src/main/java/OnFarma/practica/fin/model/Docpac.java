package OnFarma.practica.fin.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import lombok.Data;

@Data
@Table("docpac")
public class Docpac {
	
	@Id
	private Long relacion;
	private String correodoctor;
	private String correopaciente;

}
