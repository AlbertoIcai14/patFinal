package OnFarma.practica.fin.model;

import lombok.Data;

@Data
public class ValidacionInico {
	//valores por defecto: correo a@a.com y clave 1
	private String c_def = "a@a.com";
	private String cl_def="1";
	
	public boolean validar(String correo, String clave) {
		if(correo==c_def) {
			if(clave==cl_def) {
				return true;
			}
		}
		return false;
		
	}
}
