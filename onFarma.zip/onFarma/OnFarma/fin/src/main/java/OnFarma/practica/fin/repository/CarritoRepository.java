package OnFarma.practica.fin.repository;

import java.util.Set;

import org.springframework.data.jdbc.repository.query.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import OnFarma.practica.fin.model.Carrito;


public interface CarritoRepository extends CrudRepository<Carrito, Long> {
	
	@Query("SELECT * FROM carrito WHERE correo =:direccionCorreo")
	Set<Carrito>findByCorreo(@Param("direccionCorreo") String direccionCorreo);
	
	@Query("SELECT * FROM carrito WHERE correo =:direccionCorreo AND control =:control")
	Set<Carrito>findByControl(@Param("direccionCorreo") String direccionCorreo, @Param("control") String control);
	
	@Query("SELECT * FROM carrito WHERE correo =:direccionCorreo AND control =:control")
	Set<Carrito>findByNoControl(@Param("direccionCorreo") String direccionCorreo, @Param("control") String control);
}
