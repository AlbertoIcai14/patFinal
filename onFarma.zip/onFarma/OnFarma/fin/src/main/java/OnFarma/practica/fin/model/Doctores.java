package OnFarma.practica.fin.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import lombok.Data;

@Data
@Table("doctores")
public class Doctores {
	
	@Id
	private String correo;
	private String nombre;
	private String clave;
	private String correopaciente;

}
