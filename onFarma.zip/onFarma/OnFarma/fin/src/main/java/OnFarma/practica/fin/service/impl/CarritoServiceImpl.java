package OnFarma.practica.fin.service.impl;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import OnFarma.practica.fin.model.Carrito;
import OnFarma.practica.fin.repository.CarritoRepository;
import OnFarma.practica.fin.service.CarritoService;

@Service
public class CarritoServiceImpl implements CarritoService {
	
	@Autowired
	private CarritoRepository carritoRepository;
	
	@Override
	public Set<Carrito> buscarPorCorreo(String direccionCorreo){
		return carritoRepository.findByCorreo(direccionCorreo);
	}
	
	@Override
	public Set<Carrito> buscarPorComprado(String direccionCorreo, String control){
		return carritoRepository.findByControl(direccionCorreo, control);
	}
	
	@Override
	public Set<Carrito> buscarPorNoComprado(String direccionCorreo, String control){
		return carritoRepository.findByNoControl(direccionCorreo, control);
	}
	
	@Override
	public Carrito crearItem(Carrito carrito) {
		return carritoRepository.save(carrito);
	}
	
	@Override
	public Carrito actualizarCarrito(Carrito carrito) {
		return carritoRepository.save(carrito);
	}
	
	@Override
	public void borrarCarrito(Carrito carrito) {
		carritoRepository.delete(carrito);
	}
}
