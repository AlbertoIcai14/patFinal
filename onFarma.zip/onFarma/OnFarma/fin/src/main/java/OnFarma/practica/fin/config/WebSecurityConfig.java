/*
package OnFarma.practica.fin.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig extends WebSecurityConfigurerAdapter{
	
	@Override
	protected void configure(HttpSecurity httpSecurity) throws Exception {
		httpSecurity
				.headers()
				.and()
				.csrf().disable()
				.authorizeRequests()
				.antMatchers("/onBorrar.html","onBusqueda","onBusquedaReg","onCarrito",
						"onCuenta","onIndex","onModificar","onRegistro","onSesion","onTiendas").permitAll()
				.antMatchers("/api/login").permitAll()
				.anyRequest()
				.authenticated()
				.and()

				.sessionManagement()
				.sessionCreationPolicy(SessionCreationPolicy.STATELESS);

	}
}
*/
