	package OnFarma.practica.fin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import OnFarma.practica.fin.model.CentrosSaludSearchModel;
import OnFarma.practica.fin.model.FarmaSearchModel;
import OnFarma.practica.fin.model.User;
import OnFarma.practica.fin.service.CentrosSaludService;
import OnFarma.practica.fin.service.impl.FarmaService;



@RestController
@RequestMapping("/api")
public class RestControllerFin {
	private String c_def = "a@a.com";
	private String cl_def="a";

	@Autowired
	private FarmaService farmaservice;
	
	
	@Autowired
	private CentrosSaludService centrosSaludService;
	
	@GetMapping("/centrosSalud")
	public ResponseEntity<CentrosSaludSearchModel> centrosSalud(@RequestParam("atributo") String atributo, @RequestParam("busqueda") String busqueda){
		return new ResponseEntity<>(centrosSaludService.getCentrosSalud(atributo, busqueda), HttpStatus.OK);
	}
	

	//Muesta la informaciÃ³n del usuario
	@PostMapping("/contact")
	public ResponseEntity<String> getInfoUser(@RequestParam("correo") String correo){
	/*list=userservice.userlist;
	Iterator iter = list.iterator();
	while (iter.hasNext()) {
		User u2 = (User) iter.next();
		if(u2.getCorreo().equals(correo)) {}
			return new ResponseEntity<>("u2", HttpStatus.OK);
		}*/
	//devuelvo el mismo usuario que le paso
	return new ResponseEntity<>(correo, HttpStatus.OK);
	
}

	
	@GetMapping("/medicamentos")
	//@RequestMapping busca un parametro en la request que se llame busqueda y lo introduce en busqueda
	public ResponseEntity<FarmaSearchModel> bandera(@RequestParam("busqueda") String busqueda) {
		return new ResponseEntity<>(farmaservice.getMedicamentos(busqueda),HttpStatus.OK);
	}
	
	@GetMapping("/registros")
	//@RequestMapping busca un parametro en la request que se llame busqueda y lo introduce en busqueda
	public ResponseEntity<FarmaSearchModel> registro(@RequestParam("busqueda") String busqueda) {
		return new ResponseEntity<>(farmaservice.getRegistros(busqueda),HttpStatus.OK);
	}
	
	
	
	

}
