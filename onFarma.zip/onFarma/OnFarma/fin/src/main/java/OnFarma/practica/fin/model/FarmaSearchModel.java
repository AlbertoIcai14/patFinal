package OnFarma.practica.fin.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "nregistro",
    "nombre",
    "pactivos",
    "excip",
    "labtitular",
    "dispensacion",
    "tipoMedicamento",
    "administracion",
    "forma",
    "primeraAutorizacion",
    "sitadm",
    "estado",
    "comerc",
    "psum",
    "receta",
    "estupefaciente",
    "psicotropo",
    "antibiotico",
    "notas",
    "ema",
    "docs",
    "atcs",
    "principiosActivos",
    "excipientes",
    "viasAdministracion",
    "especies",
    "indicaciones",
    "contraindicaciones",
    "interacciones",
    "reaccionesAdversas",
    "tiemposEspera",
    "presentaciones"
})
public class FarmaSearchModel {

    @JsonProperty("nregistro")
    private String nregistro;
    @JsonProperty("nombre")
    private String nombre;
    @JsonProperty("pactivos")
    private String pactivos;
    @JsonProperty("excip")
    private String excip;
    @JsonProperty("labtitular")
    private String labtitular;
    @JsonProperty("dispensacion")
    private Dispensacion dispensacion;
    @JsonProperty("tipoMedicamento")
    private TipoMedicamento tipoMedicamento;
    @JsonProperty("administracion")
    private Administracion administracion;
    @JsonProperty("forma")
    private Forma forma;
    @JsonProperty("primeraAutorizacion")
    private Integer primeraAutorizacion;
    @JsonProperty("sitadm")
    private Sitadm sitadm;
    @JsonProperty("estado")
    private Estado estado;
    @JsonProperty("comerc")
    private Boolean comerc;
    @JsonProperty("psum")
    private Boolean psum;
    @JsonProperty("receta")
    private Boolean receta;
    @JsonProperty("estupefaciente")
    private Boolean estupefaciente;
    @JsonProperty("psicotropo")
    private Boolean psicotropo;
    @JsonProperty("antibiotico")
    private Boolean antibiotico;
    @JsonProperty("notas")
    private Boolean notas;
    @JsonProperty("ema")
    private Boolean ema;
    @JsonProperty("docs")
    private List<Doc> docs = null;
    @JsonProperty("atcs")
    private List<Atc> atcs = null;
    @JsonProperty("principiosActivos")
    private List<PrincipiosActivo> principiosActivos = null;
    @JsonProperty("excipientes")
    private List<Excipiente> excipientes = null;
    @JsonProperty("viasAdministracion")
    private List<ViasAdministracion> viasAdministracion = null;
    @JsonProperty("especies")
    private List<Especy> especies = null;
    @JsonProperty("indicaciones")
    private List<Indicacione> indicaciones = null;
    @JsonProperty("contraindicaciones")
    private List<Contraindicacione> contraindicaciones = null;
    @JsonProperty("interacciones")
    private List<Interaccione> interacciones = null;
    @JsonProperty("reaccionesAdversas")
    private List<ReaccionesAdversa> reaccionesAdversas = null;
    @JsonProperty("tiemposEspera")
    private List<TiemposEspera> tiemposEspera = null;
    @JsonProperty("presentaciones")
    private List<Presentacione> presentaciones = null;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("nregistro")
    public String getNregistro() {
        return nregistro;
    }

    @JsonProperty("nregistro")
    public void setNregistro(String nregistro) {
        this.nregistro = nregistro;
    }

    @JsonProperty("nombre")
    public String getNombre() {
        return nombre;
    }

    @JsonProperty("nombre")
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @JsonProperty("pactivos")
    public String getPactivos() {
        return pactivos;
    }

    @JsonProperty("pactivos")
    public void setPactivos(String pactivos) {
        this.pactivos = pactivos;
    }

    @JsonProperty("excip")
    public String getExcip() {
        return excip;
    }

    @JsonProperty("excip")
    public void setExcip(String excip) {
        this.excip = excip;
    }

    @JsonProperty("labtitular")
    public String getLabtitular() {
        return labtitular;
    }

    @JsonProperty("labtitular")
    public void setLabtitular(String labtitular) {
        this.labtitular = labtitular;
    }

    @JsonProperty("dispensacion")
    public Dispensacion getDispensacion() {
        return dispensacion;
    }

    @JsonProperty("dispensacion")
    public void setDispensacion(Dispensacion dispensacion) {
        this.dispensacion = dispensacion;
    }

    @JsonProperty("tipoMedicamento")
    public TipoMedicamento getTipoMedicamento() {
        return tipoMedicamento;
    }

    @JsonProperty("tipoMedicamento")
    public void setTipoMedicamento(TipoMedicamento tipoMedicamento) {
        this.tipoMedicamento = tipoMedicamento;
    }

    @JsonProperty("administracion")
    public Administracion getAdministracion() {
        return administracion;
    }

    @JsonProperty("administracion")
    public void setAdministracion(Administracion administracion) {
        this.administracion = administracion;
    }

    @JsonProperty("forma")
    public Forma getForma() {
        return forma;
    }

    @JsonProperty("forma")
    public void setForma(Forma forma) {
        this.forma = forma;
    }

    @JsonProperty("primeraAutorizacion")
    public Integer getPrimeraAutorizacion() {
        return primeraAutorizacion;
    }

    @JsonProperty("primeraAutorizacion")
    public void setPrimeraAutorizacion(Integer primeraAutorizacion) {
        this.primeraAutorizacion = primeraAutorizacion;
    }

    @JsonProperty("sitadm")
    public Sitadm getSitadm() {
        return sitadm;
    }

    @JsonProperty("sitadm")
    public void setSitadm(Sitadm sitadm) {
        this.sitadm = sitadm;
    }

    @JsonProperty("estado")
    public Estado getEstado() {
        return estado;
    }

    @JsonProperty("estado")
    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    @JsonProperty("comerc")
    public Boolean getComerc() {
        return comerc;
    }

    @JsonProperty("comerc")
    public void setComerc(Boolean comerc) {
        this.comerc = comerc;
    }

    @JsonProperty("psum")
    public Boolean getPsum() {
        return psum;
    }

    @JsonProperty("psum")
    public void setPsum(Boolean psum) {
        this.psum = psum;
    }

    @JsonProperty("receta")
    public Boolean getReceta() {
        return receta;
    }

    @JsonProperty("receta")
    public void setReceta(Boolean receta) {
        this.receta = receta;
    }

    @JsonProperty("estupefaciente")
    public Boolean getEstupefaciente() {
        return estupefaciente;
    }

    @JsonProperty("estupefaciente")
    public void setEstupefaciente(Boolean estupefaciente) {
        this.estupefaciente = estupefaciente;
    }

    @JsonProperty("psicotropo")
    public Boolean getPsicotropo() {
        return psicotropo;
    }

    @JsonProperty("psicotropo")
    public void setPsicotropo(Boolean psicotropo) {
        this.psicotropo = psicotropo;
    }

    @JsonProperty("antibiotico")
    public Boolean getAntibiotico() {
        return antibiotico;
    }

    @JsonProperty("antibiotico")
    public void setAntibiotico(Boolean antibiotico) {
        this.antibiotico = antibiotico;
    }

    @JsonProperty("notas")
    public Boolean getNotas() {
        return notas;
    }

    @JsonProperty("notas")
    public void setNotas(Boolean notas) {
        this.notas = notas;
    }

    @JsonProperty("ema")
    public Boolean getEma() {
        return ema;
    }

    @JsonProperty("ema")
    public void setEma(Boolean ema) {
        this.ema = ema;
    }

    @JsonProperty("docs")
    public List<Doc> getDocs() {
        return docs;
    }

    @JsonProperty("docs")
    public void setDocs(List<Doc> docs) {
        this.docs = docs;
    }

    @JsonProperty("atcs")
    public List<Atc> getAtcs() {
        return atcs;
    }

    @JsonProperty("atcs")
    public void setAtcs(List<Atc> atcs) {
        this.atcs = atcs;
    }

    @JsonProperty("principiosActivos")
    public List<PrincipiosActivo> getPrincipiosActivos() {
        return principiosActivos;
    }

    @JsonProperty("principiosActivos")
    public void setPrincipiosActivos(List<PrincipiosActivo> principiosActivos) {
        this.principiosActivos = principiosActivos;
    }

    @JsonProperty("excipientes")
    public List<Excipiente> getExcipientes() {
        return excipientes;
    }

    @JsonProperty("excipientes")
    public void setExcipientes(List<Excipiente> excipientes) {
        this.excipientes = excipientes;
    }

    @JsonProperty("viasAdministracion")
    public List<ViasAdministracion> getViasAdministracion() {
        return viasAdministracion;
    }

    @JsonProperty("viasAdministracion")
    public void setViasAdministracion(List<ViasAdministracion> viasAdministracion) {
        this.viasAdministracion = viasAdministracion;
    }

    @JsonProperty("especies")
    public List<Especy> getEspecies() {
        return especies;
    }

    @JsonProperty("especies")
    public void setEspecies(List<Especy> especies) {
        this.especies = especies;
    }

    @JsonProperty("indicaciones")
    public List<Indicacione> getIndicaciones() {
        return indicaciones;
    }

    @JsonProperty("indicaciones")
    public void setIndicaciones(List<Indicacione> indicaciones) {
        this.indicaciones = indicaciones;
    }

    @JsonProperty("contraindicaciones")
    public List<Contraindicacione> getContraindicaciones() {
        return contraindicaciones;
    }

    @JsonProperty("contraindicaciones")
    public void setContraindicaciones(List<Contraindicacione> contraindicaciones) {
        this.contraindicaciones = contraindicaciones;
    }

    @JsonProperty("interacciones")
    public List<Interaccione> getInteracciones() {
        return interacciones;
    }

    @JsonProperty("interacciones")
    public void setInteracciones(List<Interaccione> interacciones) {
        this.interacciones = interacciones;
    }

    @JsonProperty("reaccionesAdversas")
    public List<ReaccionesAdversa> getReaccionesAdversas() {
        return reaccionesAdversas;
    }

    @JsonProperty("reaccionesAdversas")
    public void setReaccionesAdversas(List<ReaccionesAdversa> reaccionesAdversas) {
        this.reaccionesAdversas = reaccionesAdversas;
    }

    @JsonProperty("tiemposEspera")
    public List<TiemposEspera> getTiemposEspera() {
        return tiemposEspera;
    }

    @JsonProperty("tiemposEspera")
    public void setTiemposEspera(List<TiemposEspera> tiemposEspera) {
        this.tiemposEspera = tiemposEspera;
    }

    @JsonProperty("presentaciones")
    public List<Presentacione> getPresentaciones() {
        return presentaciones;
    }

    @JsonProperty("presentaciones")
    public void setPresentaciones(List<Presentacione> presentaciones) {
        this.presentaciones = presentaciones;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
