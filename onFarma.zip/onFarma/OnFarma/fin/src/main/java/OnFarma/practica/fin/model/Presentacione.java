package OnFarma.practica.fin.model;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cn",
    "nombre",
    "estado",
    "comerc",
    "psum"
})
public class Presentacione {

    @JsonProperty("cn")
    private String cn;
    @JsonProperty("nombre")
    private String nombre;
    @JsonProperty("estado")
    private Estado_ estado;
    @JsonProperty("comerc")
    private Boolean comerc;
    @JsonProperty("psum")
    private Boolean psum;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("cn")
    public String getCn() {
        return cn;
    }

    @JsonProperty("cn")
    public void setCn(String cn) {
        this.cn = cn;
    }

    @JsonProperty("nombre")
    public String getNombre() {
        return nombre;
    }

    @JsonProperty("nombre")
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @JsonProperty("estado")
    public Estado_ getEstado() {
        return estado;
    }

    @JsonProperty("estado")
    public void setEstado(Estado_ estado) {
        this.estado = estado;
    }

    @JsonProperty("comerc")
    public Boolean getComerc() {
        return comerc;
    }

    @JsonProperty("comerc")
    public void setComerc(Boolean comerc) {
        this.comerc = comerc;
    }

    @JsonProperty("psum")
    public Boolean getPsum() {
        return psum;
    }

    @JsonProperty("psum")
    public void setPsum(Boolean psum) {
        this.psum = psum;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
