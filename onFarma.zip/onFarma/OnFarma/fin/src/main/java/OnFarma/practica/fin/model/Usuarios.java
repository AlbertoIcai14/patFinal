package OnFarma.practica.fin.model;


import org.springframework.data.annotation.Id;
import org.springframework.data.relational.core.mapping.Table;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
@Table("usuarios")
public class Usuarios {
	
	@Id
	private Long idusuario;
	private String correo;
	private String nombre;
	private String clave;
	private String dni;	
}
