#CREATE DATABASE IF NOT EXISTS onfarma;

#USE onfarma;

CREATE TABLE IF NOT EXISTS usuarios(
	idusuario INT AUTO_INCREMENT PRIMARY KEY,
	correo VARCHAR(256) UNIQUE,
	nombre VARCHAR(256),
    clave VARCHAR(16),
    dni VARCHAR(16)
    );


CREATE TABLE IF NOT EXISTS carrito(
  idcompra INT AUTO_INCREMENT PRIMARY KEY,
  medicamento VARCHAR(45),
  codigoproducto VARCHAR(256),
  cantidad INT,
  correo VARCHAR(45),
  control INT
  );



CREATE TABLE IF NOT EXISTS doctores(
	correo VARCHAR(45) PRIMARY KEY,
    nombre VARCHAR(45),
    clave VARCHAR(45),
    correopaciente VARCHAR(256)
);


CREATE TABLE IF NOT EXISTS docpac(
	relacion INT AUTO_INCREMENT PRIMARY KEY,
    correodoctor VARCHAR(45),
    correopaciente VARCHAR(45)
);

#INSERT INTO usuarios(correo, nombre, clave, dni) VALUES
#('alb@hotmail.es', 'Alberto', 'mysql14', '51734452J'),
#('law@gmail.com', 'Lawrence', 'law17', '52357736Z');

#INSERT INTO carrito(medicamento, codigoproducto, cantidad, correo, control) VALUES
#('Paracetamol', '2463725', '1', 'law@gmail.com', '1'),
#('Ibuprofeno', '57352725', '2', 'alb@hotmail.es', '0');
